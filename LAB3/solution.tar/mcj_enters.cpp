#include "mcj_enters.hpp"


//Privats:
//-------------------
mcj_enters::node* mcj_enters::copiar(const node* origen)
{
//Pre: el parametre implicit es buit
//Post: copia el mcj m al parametre implicit

	node* desti = NULL;
    if (origen != NULL) {
      desti = new node;
      desti->info = origen->info;
      
      // copia la resta de la llista
      desti->seg = copiar(origen->seg);  
    }
    return desti;
	
}
//-----------------
// Constructora per defecte. Crea un multiconjunt buit.
mcj_enters::mcj_enters()
{
	_prim = NULL;
	_long = 0;
}

// Les tres grans: Constructora per còpia, destructora, operador d'assignació
mcj_enters::mcj_enters(const mcj_enters &cj)
{	
	_prim = copiar(cj._prim);
	_long = cj._long;	
}

mcj_enters::~mcj_enters()
{
	node *p = _prim, *pelim;
  	    while (p != NULL) {
    		pelim = p;
    		p = p->seg;
    		delete pelim;
    	}
}

mcj_enters& mcj_enters::operator=(const mcj_enters &cj)
{
	_prim = copiar(cj._prim);
	_long = cj._long;
	return *this;	
}

// Insereix l’enter e en el multiconjunt.
void mcj_enters::insereix(int e)
//Pre: e es un enter
//Post: Insereix e de forma ordenada al multiconjunt
{
/*
	Es recorre la llista fins arribar al element on s'ha d'inserir, llavors s'enllaça la llista.
*/
	node *p = new node;
	
	p->info = e;
	
	if(_prim == NULL){
		
		p->seg = NULL;
		_prim = p;
		
	}
	else{
	
		node *aux = _prim;
		
		while (aux != NULL && aux->info < e){		//Arribem a la posicio on s'ha d'inserir el node.
			
			if (aux->seg == NULL)	//No s'ha d'arribar al final del multiconjunt.
				break;
			else if(aux->seg->info > e)	//Hem d'arribar a l'element anterior mes gran que e
				break;
			else
				aux = aux->seg;
			
		}
		if(aux == _prim && aux->info > e){
		
			p->seg = aux;
			_prim = p;
		
		}
		else{
			p->seg = aux->seg;
			aux->seg = p;
		}
		
		
		  //     1 2
		
		
	}
	_long++;
	
}

// Unió, intersecció i diferència de multiconjunts. Operen modificant el multiconjunt sobre el que s’aplica
// el mètode, usant el segon multiconjunt com argument. P.e.: a.restar(b) fa que el nou valor d’a sigui
  // A - B, on A i B són els valors originals dels objectes a i b.
void mcj_enters::unir(const mcj_enters& B)
//Pre: el multiconjunt esta ordenat
//Post: Copia la unio del multiconjunt implicit amb el del parametre B  
{
	mcj_enters _a;		//Variable de suport 
	
	node *aux1 = _prim;
	
	node *aux2 = B._prim;
	
	while (aux1 != NULL && aux2 != NULL){
	
		if (aux1->info < aux2->info){
		
            		_a.insereix(aux1->info); //Insereix multiconj[i] i incrementa i
            		aux1 = aux1->seg;
            	}
  
        	else if (aux2->info < aux1->info){
        	
            		_a.insereix(aux2->info);
            		aux2 = aux2->seg;
            	}
  
        	else {
        		
            		_a.insereix(aux1->info);
            		aux1 = aux1->seg;
            		aux2 = aux2->seg;
	
		}
	
	
	}
	while (aux1 != NULL){
		_a.insereix(aux1->info);
		aux1 = aux1->seg;
	}
	while (aux2 != NULL){
		_a.insereix(aux2->info);
		aux2 = aux2->seg;
	}


	node *p = _prim, *pelim;
  	    while (p != NULL) {
    		pelim = p;
    		p = p->seg;
    		delete pelim;
    	}
	//borrem els nodes anteriors
	_prim = copiar(_a._prim);


}
void mcj_enters::intersectar(const mcj_enters& B)
//Pre: elS multiconjuntS estaN ordenatS
//Post: Copia la interseccio del multiconjunt implicit amb el del parametre B 
{

	mcj_enters _a;		//Variable de suport 
	
	node *aux1 = _prim;
	
	node *aux2 = B._prim;
	
	while (aux1 != NULL && aux2 != NULL){
	
		if (aux1->info < aux2->info)
            		aux1 = aux1->seg;
            	
        	else if (aux2->info < aux1->info)
            		aux2 = aux2->seg;
            	
        	else {
        	
            		_a.insereix(aux1->info);
            		aux1 = aux1->seg;
            		aux2 = aux2->seg;
	
		}
	
	
	}

	node *p = _prim, *pelim;
  	    while (p != NULL) {
    		pelim = p;
    		p = p->seg;
    		delete pelim;
    	}
	//borrem els nodes anteriors

	_prim = copiar(_a._prim);

}
void mcj_enters::restar(const mcj_enters& B)
//Pre: Els multiconjunts estan ordenats
//Post: Copia el multiconjunt resultant de la resta de A i B, al parametre implicit 
{

	mcj_enters _a;		//Variable de suport 
	
	node *aux1 = _prim;
	
	node *aux2 = B._prim;
	
	while (aux1 != NULL){

		if (aux2 == NULL) break;
	
		if(aux1->info < aux2->info){
		
			_a.insereix(aux1->info);
			aux1 = aux1->seg;
		}
		else{
			if(! (aux2->info < aux1->info))
				aux1 = aux1->seg;
			
			aux2 = aux2->seg;
		}
		
	
	}
	while (aux1 != NULL){
		_a.insereix(aux1->info);
		aux1 = aux1->seg;
	}
	
	node *p = _prim, *pelim;
  	    while (p != NULL) {
    		pelim = p;
    		p = p->seg;
    		delete pelim;
    	}
	//borrem els nodes anteriors

	_prim = copiar(_a._prim);
	
}

  // Unió, intersecció i diferència de multiconjunts. Operen creant un nou multiconjunt sense modificar el con-
  // junt sobre el que s’aplica el mètode. La suma de multiconjunts correspon a la unió, la resta a la
  // diferència i el producte a la intersecció.
mcj_enters mcj_enters::operator+(const mcj_enters& B) const
//Pre: Els multiconjunts estan ordenats
//Post: Retorna un multiconjunt resultant de la suma (unio) de A i B
{	
	mcj_enters _a(*this);		//Variable de suport 
	
	_a.unir(B);

	return _a;
}

mcj_enters mcj_enters::operator*(const mcj_enters& B) const
//Pre: Els multiconjunts esta ordenats
//Post: Retorna un multiconjunt resultant del producte (interseccio) de A i B
{
	mcj_enters _a(*this);		//Variable de suport 
	
	_a.intersectar(B);

	return _a;
}

mcj_enters mcj_enters::operator-(const mcj_enters& B) const
//Pre: Els multiconjunts estan ordenats
//Post: Retorna un multiconjunt resultant de la resta de A i B
{
	mcj_enters _a(*this);		//Variable de suport 
	
	_a.restar(B);

	return _a;
}

// Retorna cert si i només si e pertany al multiconjunt.
bool mcj_enters::conte(int e) const
//Pre:
//Post: retorna cert si "e" pertany al multiconjunt.
{	
	if (_prim == NULL){
		
		return false;
	
	}
	else{
	
		node *aux = _prim;
		
		while (aux != NULL){
		
			if (aux->info == e){
			
				return true;
			
			}
			aux = aux->seg;
		}
	
	
	}
	return false;
	
}

// Retornen els elements màxim i mínim del multiconjunt, respectivament.
// El seu comportament no està definit si el multiconjunt és buit.
int mcj_enters::max() const
//Pre:
//Post: retorna el maxim del multiconjunt
{
	node *aux = _prim;
	while(aux != NULL){
	
		if(aux->seg == NULL)	//Bucle per arribar al final del multiconjunt.
			break;
		
		aux = aux->seg;
	
	}
	if(aux != NULL) 
		return aux->info;

	else return -1;				//No s'hauria de donar aquest cas de multiconjunt buit, segons el jutge.
}

int mcj_enters::min() const
//Pre:
//Post: retorna el minim del multiconjunt
{
	if (_prim != NULL)

		return _prim->info;

	else return -1;				//No s'hauria de donar aquest cas de multiconjunt buit, segons el jutge.
}

// Retorna el nombre d’elements (la cardinalitat) del multiconjunt.
int mcj_enters::card() const
{
	return _long;
}

// Operadors relacionals. == retorna cert si i només si els
// dos multiconjunts (el paràmetre implícit i B) contenen els
// mateixos elements; != retorna cert si i només si els
// multiconjunts són diferents.
bool mcj_enters::operator==(const mcj_enters& B) const
//Pre: el multiconjunt esta ordenat de forma ascendent.
//Post: Retorna si el multiconjunt B es igual al multiconjunt implicit.
{
	if(_long != B._long)

		return false;

	else{
		node *aux1 = _prim;
		node *aux2 = B._prim;
		
		while (aux1 != NULL){
		
			if (aux1->info != aux2->info)
				return false;
		
			aux1 = aux1->seg;
			aux2 = aux2->seg;
		}
		
		return true;
	}
}

bool mcj_enters::operator!=(const mcj_enters& B) const
//Pre: el multiconjunt esta ordenat de forma ascendent.
//Post: Retorna si el multiconjunt B no es igual al multiconjunt implicit.
{
	return !(*this == B);
}

// Imprimeix el multiconjunt d’enters, ordenats en ordre ascendent, sobre
// el canal de sortida os; el format és [e1 e2 ... en], és a dir, amb
// espais entre els elements i tancant la seqüència amb corxets.
void mcj_enters::print(ostream& os) const
//Pre: EL multiconjunt esta ordenat
//Post: imprimeix el multiconjunt pel canal de sortida os
{

	os << "[";
	
	node *aux = _prim;
	
	while (aux != NULL){
	
		os << aux->info;
		
		aux = aux->seg;
		
		if (aux != NULL) os << " ";
		
	}
	 os << "]";
	

}
